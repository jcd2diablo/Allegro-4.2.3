#define rmac_message	128		/*message window ID*/
#define rerror_str		128		/*errors str*/

#define kprefsize		16384	/* kbytes */
#define kminsize		10000
#define kStackNeeded	2048*1024 /*unsual stack requeriment? but allegro need*/
#define kHeapNeeded		8192*1024 /*it's a game OK*/