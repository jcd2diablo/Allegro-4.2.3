Allegro 4.2.3
  for MSVC 10

Packaged by Matthew Leverton <http://allegro.cc>

= Resources =

* Get the latest installation instructions at <http://wiki.allegro.cc>

  * http://wiki.allegro.cc/Getting_Started
  * http://wiki.allegro.cc/Category:IDE_Configuration

* Download the examples and demo program at <http://allegro.cc/files>

* Download a free PDF manual or buy the printed manual at:

  * Paperback
    http://www.lulu.com/content/paperback-book/allegro-423-api-reference-manual/8426795 

  * Paperback (Higher Quality, cheaper international shipping)
    http://www.lulu.com/content/paperback-book/allegro-423-api-reference-manual/8426840 

  * Hard cover
    http://www.lulu.com/content/hardcover-book/allegro-423-api-reference-manual/8426850 


  (There is a free downloadable PDF at each link.)