
#include <stdio.h>
#include "allegro.h"

#define BLACK makecol(0,0,0)
#define WHITE makecol(255,255,255)

//define the sprite structure
typedef struct SPRITE
{
	int x,y;
	int width,height;
	int xspeed,yspeed;
	int xdelay,ydelay;
	int xcount,ycount;
	int curframe,maxframe,animdir;
	int framecount,framedelay;
	
}SPRITE;

//sprite variables
RLE_SPRITE *dragonimg[6];
SPRITE thedragon;
SPRITE *dragon = &thedragon;


void erasesprite(BITMAP *dest, SPRITE *spr)
{
    //erase the sprite using BLACK color fill
    rectfill(dest, spr->x, spr->y, spr->x + spr->width, 
        spr->y + spr->height, BLACK);
}

void updatesprite(SPRITE *spr)
{
    //update x position
    if (++spr->xcount > spr->xdelay)
    {
        spr->xcount = 0;
        spr->x += spr->xspeed;
    }

    //update y position
    if (++spr->ycount > spr->ydelay)
    {
        spr->ycount = 0;
        spr->y += spr->yspeed;
    }

    //update frame based on animdir
    if (++spr->framecount > spr->framedelay)
    {
        spr->framecount = 0;
        if (spr->animdir == -1)
        {
            if (--spr->curframe < 0)
                spr->curframe = spr->maxframe;
        }
        else if (spr->animdir == 1)
        {
            if (++spr->curframe > spr->maxframe)
                spr->curframe = 0;
        }
    }
}

void warpsprite(SPRITE *spr)
{
    //simple screen warping behavior
    if (spr->x < 0)
    {
        spr->x = SCREEN_W - spr->width;
    }

    else if (spr->x > SCREEN_W - spr->width)
    {
        spr->x = 0;
    }

    if (spr->y < 40)
    {
        spr->y = SCREEN_H - spr->height;
    }

    else if (spr->y > SCREEN_H - spr->height)
    {
        spr->y = 40;
    }

}

RLE_SPRITE *rle_grabframe(BITMAP *source, 
                  int width, int height, 
                  int startx, int starty, 
                  int columns, int frame)
{
    RLE_SPRITE *sprite;
    BITMAP *temp = create_bitmap(width,height);

    int x = startx + (frame % columns) * width;
    int y = starty + (frame / columns) * height;
    
    blit(source,temp,x,y,0,0,width,height);
    sprite = get_rle_sprite(temp);
    destroy_bitmap(temp);

    return sprite;
    
}

void main(void)
{
    BITMAP *temp;
    int n, x, y;

    //initialize
    allegro_init();
    set_color_depth(16);
    set_gfx_mode(GFX_AUTODETECT_WINDOWED, 640, 480, 0, 0);
    install_keyboard();
    install_timer();
    srand(time(NULL));
    textout(screen, font, "RLE Sprites Program (ESC to quit)", 
        0, 0, WHITE);
    
    //load and draw the blocks
    temp = load_bitmap("block1.bmp", NULL);
    for (y=0; y < SCREEN_H/2/temp->h+temp->h; y++)
        for (x=0; x < SCREEN_W/temp->w; x++)
            draw_sprite(screen, temp, x*temp->w, SCREEN_H/2+y*temp->h);
    destroy_bitmap(temp);

    temp = load_bitmap("block2.bmp", NULL);
    for (x=0; x < SCREEN_W/temp->w; x++)
        draw_sprite(screen, temp, x*temp->w, SCREEN_H/2);
    destroy_bitmap(temp);


    //load rle sprite
    temp = load_bitmap("dragon.bmp", NULL);
    for (n=0; n<6; n++)
        dragonimg[n] = rle_grabframe(temp,128,64,0,0,3,n);
    destroy_bitmap(temp);


    //initialize the sprite with lots of randomness
    dragon->x = 500;
    dragon->y = 150;
    dragon->width = dragonimg[0]->w;
    dragon->height = dragonimg[0]->h;
    dragon->xdelay = 1;
    dragon->ydelay = 0;
    dragon->xcount = 0;
    dragon->ycount = 0;
    dragon->xspeed = -4;
    dragon->yspeed = 0;
    dragon->curframe = 0;
    dragon->maxframe = 5;
    dragon->framecount = 0;
    dragon->framedelay = 10;
    dragon->animdir = 1;

    //game loop
    while (!key[KEY_ESC])
    {
        //erase the dragon
        erasesprite(screen, dragon);

        //move/animate the dragon
        updatesprite(dragon);
        warpsprite(dragon);

        //draw the dragon
        acquire_screen();
        draw_rle_sprite(screen, dragonimg[dragon->curframe], dragon->x, dragon->y);
        release_screen();

        rest(10);
    }

    for (n=0; n<6; n++)
        destroy_rle_sprite(dragonimg[n]);

    return;
}

END_OF_MAIN();

