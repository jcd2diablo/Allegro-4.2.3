/* Allegro datafile object indexes, produced by dat v4.0.3, MSVC.s */
/* Datafile: test.dat */
/* Date: Thu Apr 15 20:49:59 2004 */
/* Do not hand edit! */

#define BACK_BMP                         0        /* BMP  */
#define SHIP_BMP                         1        /* BMP  */

