alleg40.dll gets copied to your windows dir if you ran "make install" but if not, I'm putting a copy at the root of this chapter. in future chapters I probably won't do this.
