Due to the nature of Allegro, it was problematic to compile a Win32 Console program under Visual C++, so the project was not included here (this is the only Visual C++ program not included--all the rest of the programs in the book are available for this compiler). Sorry for the inconvenience.

