
#include <conio.h>
#include <stdio.h>

int main()
{
    printf("Greetings Earthlings.\n");
    printf("All your base are belong to us!\n");
    getch();
}


