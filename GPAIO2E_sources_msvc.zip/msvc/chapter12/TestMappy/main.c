

#include "allegro.h"
#include "mappyal.h"

#define MODE GFX_AUTODETECT_FULLSCREEN
#define WIDTH 640
#define HEIGHT 480
#define WHITE makecol(255,255,255)

//x, y offset in pixels 
int xoffset = 0;
int yoffset = 0;

//double buffer
BITMAP *buffer;	

void main (void)
{
    //initialize program
	allegro_init();	
	install_timer();
	install_keyboard();
	set_gfx_mode(MODE, WIDTH, HEIGHT, 0, 0);
    text_mode(-1);

    //create the double buffer and clear it
	buffer = create_bitmap(SCREEN_W, SCREEN_H);	
	if (buffer==NULL) 
    { 
        allegro_message("Error creating double buffer");
        return;
    }
	clear(buffer);

    //load the Mappy file
	if (MapLoad("map1.fmp"))
    {
		allegro_message ("Can't find map1.fmp");
		return;
	}

    //set palette
    MapSetPal8();

    //main loop
    while (!key[KEY_ESC])
	{
        //draw map with single layer
        MapDrawBG(buffer, xoffset, yoffset, 0, 0, SCREEN_W-1, SCREEN_H-1);

        //blit the double buffer
		blit (buffer, screen, 0, 0, 0, 0, SCREEN_W-1, SCREEN_H-1);

        //check for keyboard input
		if (key[KEY_RIGHT]) 
        {
            xoffset+=4; 
            //make sure it doesn't scroll beyond map edge
            if (xoffset > 31*32) xoffset = 31*32;
        }
		if (key[KEY_LEFT]) 
        {
            xoffset-=4; 
            if (xoffset < 0) xoffset = 0;
        }
		if (key[KEY_UP]) 
        {
            yoffset-=4; 
            if (yoffset < 0) yoffset = 0;
        }
		if (key[KEY_DOWN]) 
        {
            yoffset+=4; 
            //make sure it doesn't scroll beyond map edge
            if (yoffset > 33*32) yoffset = 33*32;
        }

	}

    //delete double buffer
	destroy_bitmap(buffer);

    //delete the Mappy level
	MapFreeMem();

	allegro_exit();
	return;
}

END_OF_MAIN()

