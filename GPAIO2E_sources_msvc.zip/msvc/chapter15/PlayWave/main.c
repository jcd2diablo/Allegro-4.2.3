
#include <allegro.h>

#define MODE GFX_AUTODETECT_WINDOWED
#define WIDTH 640
#define HEIGHT 480
#define WHITE makecol(255,255,255)

void main(void)
{
    SAMPLE *sample;
    int panning = 128;
    int pitch = 1000;
    int volume = 128;

    //initialize the program
    allegro_init();
    install_keyboard(); 
    install_timer();
    set_color_depth(16);
    set_gfx_mode(MODE, WIDTH, HEIGHT, 0, 0);
    text_mode(0);

    //install a digital sound driver
    if (install_sound(DIGI_AUTODETECT, MIDI_NONE, "") != 0) 
    {
        allegro_message("Error initialising sound system");
        return;
    }

    //display program information
    textout(screen,font,"PlayWave Program (ESC to quit)",0,0,WHITE);
    textprintf(screen,font,0,10,WHITE,"Sound Driver: %s",digi_driver->name);
    textout(screen,font,"Playing clapping.wav...",0,20,WHITE);
    textout(screen,font,"Left,Right - Pan Left,Right",0,50,WHITE);
    textout(screen,font,"Up,Down    - Pitch Raise,Lower",0,60,WHITE);
    textout(screen,font,"-,+        - Volume Down,Up",0,70,WHITE);

    //load the wave file
    sample = load_sample("clapping.wav");
    if (!sample) 
    {
        allegro_message("Error reading wave file");
        return;
    }

    //play the sample with looping
    play_sample(sample, volume, pan, pitch, TRUE);


    //main loop
    while (!key[KEY_ESC]) 
    {
        //change the panning
        if ((key[KEY_LEFT]) && (panning > 0))
            panning--;
        else if ((key[KEY_RIGHT]) && (panning < 255))
            panning++;

        //change the pitch (rounding at 512)
        if ((key[KEY_UP]) && (pitch < 16384))
            pitch = ((pitch * 513) / 512) + 1; 
        else if ((key[KEY_DOWN]) && (pitch > 64))
            pitch = ((pitch * 511) / 512) - 1; 

        //change the volume
        if (key[KEY_EQUALS] && volume < 255)
            volume++;
        else if (key[KEY_MINUS] && volume > 0)
            volume--;

        //adjust the sample
        adjust_sample(sample, volume, pan, pitch, TRUE);

        //pause
        rest(5);

        //display status
        textprintf(screen,font,0,100,WHITE,"PITCH: %5d", pitch);
        textprintf(screen,font,0,110,WHITE,"PAN:   %5d", panning);
        textprintf(screen,font,0,120,WHITE,"VOLUME:%5d", volume);
    }

    //destroy the sample
    destroy_sample(sample);

    //remove the sound driver
    remove_sound();

    return;
}

END_OF_MAIN();