
#include <allegro.h>

#define MODE GFX_AUTODETECT_WINDOWED
#define WIDTH 640
#define HEIGHT 480
#define WHITE makecol(255,255,255)

void main(void)
{
    SAMPLE *samples[5];
    int volume = 128;
    int pan = 128;
    int pitch = 1000;
    int n;

    //initialize the program
    allegro_init();
    install_keyboard(); 
    install_timer();
    set_color_depth(16);
    set_gfx_mode(MODE, WIDTH, HEIGHT, 0, 0);
    text_mode(0);

    //install a digital sound driver
    if (install_sound(DIGI_AUTODETECT, MIDI_NONE, "") != 0) 
    {
        allegro_message("Error initialising sound system");
        return;
    }

    //display program information
    textout(screen,font,"SampleMixer Program (ESC to quit)",0,0,WHITE);
    textprintf(screen,font,0,10,WHITE,"Sound Driver: %s", digi_driver->name);

    //display simple menu
    textout(screen,font,"1 - Clapping Sound",0,50,WHITE);
    textout(screen,font,"2 - Bee Sound",0,60,WHITE);
    textout(screen,font,"3 - Ambulance Sound",0,70,WHITE);
    textout(screen,font,"4 - Splash Sound",0,80,WHITE);
    textout(screen,font,"5 - Explosion Sound",0,90,WHITE);

    //load the wave file
    samples[0] = load_sample("clapping.wav");
    samples[1] = load_sample("bee.wav");
    samples[2] = load_sample("ambulance.wav");
    samples[3] = load_sample("splash.wav");
    samples[4] = load_sample("explode.wav");

    //main loop
    while (!key[KEY_ESC]) 
    {
        if (key[KEY_1])
            play_sample(samples[0], volume, pan, pitch, FALSE);
        if (key[KEY_2])
            play_sample(samples[1], volume, pan, pitch, FALSE);
        if (key[KEY_3])
            play_sample(samples[2], volume, pan, pitch, FALSE);
        if (key[KEY_4])
            play_sample(samples[3], volume, pan, pitch, FALSE);
        if (key[KEY_5])
            play_sample(samples[4], volume, pan, pitch, FALSE);

        //block fast key repeats
        rest(50);
    }

    //destroy the samples
    for (n=0; n<5; n++)
        destroy_sample(samples[n]);

    //remove the sound driver
    remove_sound();

    return;
}

END_OF_MAIN();