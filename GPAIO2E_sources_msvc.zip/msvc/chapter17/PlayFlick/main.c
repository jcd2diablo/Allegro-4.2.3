
#include <stdio.h>
#include "allegro.h"

#define WHITE makecol(255,255,255)

int ret;

int fli_callback(void)
{
    //display some info after each frame
    textprintf(screen, font, 0, 0, WHITE, 
        "FLI resolution: %d x %d", fli_bitmap->w, fli_bitmap->h);
    textprintf(screen, font, 0, 10, WHITE,
        "Current frame: %2d", fli_frame);

    //ESC key stops animation
    if (key[KEY_ESC])
        return 1;
    else
        return 0;
}

void main(void)
{
    //initialize Allegro
    allegro_init();
    set_color_depth(16);
    set_gfx_mode(GFX_AUTODETECT_WINDOWED, 640, 480, 0, 0);
    install_timer();
    install_keyboard();
    
    //play fli with callback
    play_fli("particles.fli", screen, 1, fli_callback);

    //time to leave
    allegro_exit();
}

END_OF_MAIN();
