
#include <stdio.h>
#include "allegro.h"

#define WHITE makecol(255,255,255)

int ret;

void main(void)
{
    //initialize Allegro
    allegro_init();
    set_color_depth(16);
    set_gfx_mode(GFX_AUTODETECT_WINDOWED, 640, 480, 0, 0);
    install_timer();
    install_keyboard();

    //load the fli movie file
    ret = open_fli("octahedron.fli");
    if (ret != FLI_OK)
    {
        textout(screen, font, "Error loading octahedron.fli", 
            0, 30, WHITE);
        readkey();
        return;
    }

    //display movie resolution
    textprintf(screen, font, 0, 0, WHITE,
        "FLI resolution: %d x %d", fli_bitmap->w, fli_bitmap->h);

    //main loop
    while (!key[KEY_ESC])
    {
        //is it time for the next frame?
        if (fli_timer)
        {
            //open the next frame
            next_fli_frame(1);

            //adjust the palette
            set_palette(fli_palette);

            //copy the FLI frame to the screen
            blit(fli_bitmap, screen, 0, 0, 0, 30, 
                fli_bitmap->w, fli_bitmap->h);

            //display current frame
            textprintf(screen, font, 0, 10, WHITE, 
                "Current frame: %4d", fli_frame);
        }
    }

    //remove fli from memory
    close_fli();

    //time to leave
    allegro_exit();
}

END_OF_MAIN();
