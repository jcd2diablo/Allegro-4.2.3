
#include "allegro.h"

#define WHITE makecol(255,255,255)
#define BLACK makecol(0,0,0)

int ret,width,height;

void main(void)
{
    //initialize Allegro
    allegro_init();
    install_timer();
    install_keyboard();
    text_mode(-1);

    //set video mode--color depth defaults to 8-bit
    set_gfx_mode(GFX_AUTODETECT_WINDOWED, 640, 480, 0, 0);

    //load the fli movie file
    ret = open_fli("sr-71.fli");
    if (ret != FLI_OK)
    {
        textout(screen, font, "Error loading sr-71.fli", 
            0, 30, WHITE);
        readkey();
        return;
    }

    //main loop
    while (!key[KEY_ESC])
    {
        //is it time for the next frame?
        if (fli_timer)
        {
            //open the next frame
            next_fli_frame(1);

            //adjust the palette
            set_palette(fli_palette);

            //calculate scale
            width = SCREEN_W;
            height = fli_bitmap->h * (SCREEN_W / fli_bitmap->w);

            //draw scaled FLI (note: screen must be in 8-bit mode)
            stretch_blit(fli_bitmap, screen, 0, 0, fli_bitmap->w, 
                fli_bitmap->h, 0, 0, width, height);

            //display movie resolution
            textprintf(screen, font, 0, 0, BLACK,
                "FLI resolution: %d x %d", fli_bitmap->w, fli_bitmap->h);

            //display current frame
            textprintf(screen, font, 0, 10, BLACK, 
                "Current frame: %4d", fli_frame);

        }
    }

    //remove fli from memory
    close_fli();

    //time to leave
    allegro_exit();
}

END_OF_MAIN();
