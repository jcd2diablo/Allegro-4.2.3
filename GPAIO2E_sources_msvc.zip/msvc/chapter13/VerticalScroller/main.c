

#include "allegro.h"
#include "mappyal.h"

//this must run at 640x480
#define MODE GFX_AUTODETECT_FULLSCREEN
//#define MODE GFX_AUTODETECT_WINDOWED
#define WIDTH 640
#define HEIGHT 480
#define WHITE makecol(255,255,255)

#define BOTTOM 48000 - HEIGHT
//y offset in pixels 
int yoffset = BOTTOM;

//timer variables
volatile int counter;
volatile int ticks;
volatile int framerate;

//double buffer
BITMAP *buffer;	

//calculate framerate every second
void timer1(void)
{
    counter++;
    framerate = ticks;
    ticks=0;
}
END_OF_FUNCTION(timer1)


void main (void)
{
    //initialize program
	allegro_init();	
	install_timer();
	install_keyboard();
//    set_color_depth(16);
	set_gfx_mode(MODE, WIDTH, HEIGHT, 0, 0);
    text_mode(-1);

    //create the double buffer and clear it
	buffer = create_bitmap(SCREEN_W, SCREEN_H);	
	if (buffer==NULL) 
    { 
        set_gfx_mode(GFX_TEXT, 0, 0, 0, 0);
        allegro_message("Error creating double buffer");
        return;
    }
	clear(buffer);

    //load the Mappy file
	if (MapLoad("level1.fmp"))
    {
        set_gfx_mode(GFX_TEXT, 0, 0, 0, 0);
		allegro_message ("Can't find level1.fmp");
		return;
	}

    //set palette
    MapSetPal8();

    //identify variables used by interrupt function
    LOCK_VARIABLE(counter);
    LOCK_VARIABLE(framerate);
    LOCK_VARIABLE(ticks);
    LOCK_FUNCTION(timer1);

    //create new interrupt handler
    install_int(timer1, 1000);

    //main loop
    while (!key[KEY_ESC])
	{
        //check for keyboard input
		if (key[KEY_PGUP]) yoffset-=4; 
		if (key[KEY_PGDN]) yoffset+=4; 
        if (key[KEY_UP])   yoffset-=1;
        if (key[KEY_DOWN]) yoffset+=1;

        //make sure it doesn't scroll beyond map edge
        if (yoffset < 0) yoffset = 0;
        if (yoffset > BOTTOM) yoffset = BOTTOM;


        //draw map with single layer
        MapDrawBG(buffer, 0, yoffset, 0, 0, SCREEN_W-1, SCREEN_H-1);

        //update ticks
        ticks++;

        //display some status information
        textprintf(buffer,font,0,440,WHITE,"yoffset %d",yoffset);
        textprintf(buffer,font,0,450,WHITE,"counter %d", counter);
        textprintf(buffer,font,0,460,WHITE,"framerate %d", framerate);

        //blit the double buffer
        acquire_screen();
		blit (buffer, screen, 0, 0, 0, 0, SCREEN_W-1, SCREEN_H-1);
        release_screen();

	}

    //delete double buffer
	destroy_bitmap(buffer);

    //delete the Mappy level
	MapFreeMem();

	allegro_exit();
	return;
}

END_OF_MAIN()

