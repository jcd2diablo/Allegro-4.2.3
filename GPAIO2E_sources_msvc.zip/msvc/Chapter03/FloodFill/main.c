/////////////////////////////////////////////////////////////////////////
// Game Programming All In One, Second Edition
// Source Code Copyright (C)2004 by Jonathan S. Harbour
// Chapter 3 - FloodFill Program
/////////////////////////////////////////////////////////////////////////

#include "allegro.h"

void main(void)
{
    int x = 100, y = 100;
    int xdir = 10, ydir = 10;
    int red,green,blue,color;
    int radius = 50;
    int ret;
    
    //initialize some things
    allegro_init(); 
    install_keyboard(); 
    install_timer();

    //initialize video mode to 640x480
    ret = set_gfx_mode(GFX_AUTODETECT_WINDOWED, 640, 480, 0, 0);
    if (ret != 0) {
        allegro_message(allegro_error);
        return;
    }

    //display screen resolution
    textprintf(screen, font, 0, 0, 15, 
        "FloodFill Program - %dx%d - Press ESC to quit", 
        SCREEN_W, SCREEN_H);

    //wait for keypress
    while(!key[KEY_ESC])
    {
        //update the x position, keep within screen
        x += xdir;
        if (x > SCREEN_W-radius)
        {
            xdir = -10;
            radius = 10 + rand() % 40;
            x = SCREEN_W-radius;
        }
        if (x < radius)
        {
            xdir = 10;
            radius = 10 + rand() % 40;
            x = radius;
        }

        //update the y position, keep within screen
        y += ydir;
        if (y > SCREEN_H-radius)
        {
            ydir = -10;
            radius = 10 + rand() % 40;
            y = SCREEN_H-radius;
        }
        if (y < radius+20)
        {
            ydir = 10;
            radius = 10 + rand() % 40;
            y = radius+20;
        }
    
        //set a random color
        red = rand() % 255;
        green = rand() % 255;
        blue = rand() % 255;
        color = makecol(red,green,blue);
        
        //draw the circle, pause, then erase it
        circle(screen, x, y, radius, color);
        floodfill(screen, x, y, color);
        rest(20); // replaced sleep()
        rectfill(screen, x-radius, y-radius, x+radius, y+radius, 0);
    }

    //end program
    allegro_exit();
}

END_OF_MAIN();

