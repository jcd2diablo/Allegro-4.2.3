/////////////////////////////////////////////////////////////////////////
// Game Programming All In One, Second Edition
// Source Code Copyright (C)2004 by Jonathan S. Harbour
// Chapter 3 - Polygons Program
/////////////////////////////////////////////////////////////////////////

#include "allegro.h"

void main(void)
{
    int vertices[8];
    int red,green,blue,color;
    int ret;
    
    //initialize everything
    allegro_init(); 
    install_keyboard(); 
    install_timer();
    srand(time(NULL));

    //initialize video mode to 640x480
    ret = set_gfx_mode(GFX_AUTODETECT_WINDOWED, 640, 480, 0, 0);
    if (ret != 0) {
        allegro_message(allegro_error);
        return;
    }

    //display screen resolution
    textprintf(screen, font, 0, 0, 15, 
        "Polygons Program - %dx%d - Press ESC to quit", 
        SCREEN_W, SCREEN_H);

    //wait for keypress
    while(!key[KEY_ESC])
    {
        //set a random location
        vertices[0] = 10 + rand() % (SCREEN_W-20);
        vertices[1] = 10 + rand() % (SCREEN_H-20);
        vertices[2] = vertices[0] + (rand() % 30)+50;
        vertices[3] = vertices[1] + (rand() % 30)+50;
        vertices[4] = vertices[2] + (rand() % 30)-100;
        vertices[5] = vertices[3] + (rand() % 30)+50;
        vertices[6] = vertices[4] + (rand() % 30);
        vertices[7] = vertices[5] + (rand() % 30)-100;
        
        //set a random color
        red = rand() % 255;
        green = rand() % 255;
        blue = rand() % 255;
        color = makecol(red,green,blue);
        
        //draw the pixel
        polygon(screen,4,vertices,color);
        
        rest(50); //replaced sleep()
    }

    //end program
    allegro_exit();
}

END_OF_MAIN();

