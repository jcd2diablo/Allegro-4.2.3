/////////////////////////////////////////////////////////////////////////
// Game Programming All In One, Second Edition
// Source Code Copyright (C)2004 by Jonathan S. Harbour
// Chapter 3 - EllipseFill Program
/////////////////////////////////////////////////////////////////////////

#include "allegro.h"

void main(void)
{
    int x,y,radiusx,radiusy;
    int red,green,blue,color;
    int ret;
    
    //initialize everything
    allegro_init(); 
    install_keyboard(); 
    install_timer();
    srand(time(NULL));

    //initialize video mode to 640x480
    ret = set_gfx_mode(GFX_AUTODETECT_WINDOWED, 640, 480, 0, 0);
    if (ret != 0) {
        allegro_message(allegro_error);
        return;
    }

    //display screen resolution
    textprintf(screen, font, 0, 0, 15, 
        "EllipseFill Program - %dx%d - Press ESC to quit", 
        SCREEN_W, SCREEN_H);

    //wait for keypress
    while(!key[KEY_ESC])
    {
        //set a random location
        x = 30 + rand() % (SCREEN_W-60);
        y = 30 + rand() % (SCREEN_H-60);
        radiusx = rand() % 30;
        radiusy = rand() % 30;
        
        //set a random color
        red = rand() % 255;
        green = rand() % 255;
        blue = rand() % 255;
        color = makecol(red,green,blue);
        
        //draw the ellipse
        ellipsefill(screen, x, y, radiusx, radiusy, color);
        
        rest(25); //replaced sleep()
    }

    //end program
    allegro_exit();
}

END_OF_MAIN();

