/////////////////////////////////////////////////////////////////////////
// Game Programming All In One, Second Edition
// Source Code Copyright (C)2004 by Jonathan S. Harbour
// Chapter 3 - DrawBitmap Program
/////////////////////////////////////////////////////////////////////////

#include "allegro.h"

void main(void)
{
    char *filename = "allegro.pcx";
    int colordepth = 32;
    BITMAP *image;
    int ret;

    allegro_init(); 
    install_keyboard(); 

    set_color_depth(colordepth);
    ret = set_gfx_mode(GFX_AUTODETECT_WINDOWED, 640, 480, 0, 0);
    if (ret != 0) {
        allegro_message(allegro_error);
        return;
    }

    //load the image file
    image = load_bitmap(filename, NULL);
    if (!image) {
        set_gfx_mode(GFX_TEXT, 0, 0, 0, 0);
        allegro_message("Error loading %s", filename);
        return;
    }

    //display the image
    blit(image, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);

    //done drawing--delete bitmap from memory
    destroy_bitmap(image);

    //draw font with transparency
    text_mode(-1);
    
    //display video mode information
    textprintf(screen, font, 0, 0, makecol(255, 255, 255), 
        "%dx%d %ibpp", SCREEN_W, SCREEN_H, colordepth);

    //wait for keypress
    while (!key[KEY_ESC]);

    //exit program
    allegro_exit();
}

END_OF_MAIN();

