/////////////////////////////////////////////////////////////////////////
// Game Programming All In One, Second Edition
// Source Code Copyright (C)2004 by Jonathan S. Harbour
// Chapter 3 - DoLines Program
/////////////////////////////////////////////////////////////////////////

#include "allegro.h"

int stop = 0;

//doline is the callback function for do_line
void doline(BITMAP *bmp, int x, int y, int color)
{
    if (!stop)
    {
        if (getpixel(bmp,x,y) == 0)
        {
            putpixel(bmp, x, y, color);
            rest(5);
        }
        else
        {
            stop = 1;
            circle(bmp, x, y, 5, 7);
        }
    }
}

void main(void)
{
    int x1,y1,x2,y2;
    int red,green,blue,color;
    int ret;
    
    //initialize Allegro
    allegro_init(); 
    
    install_timer();
    srand(time(NULL));
    
    //initialize the keyboard
    install_keyboard(); 

    //initialize video mode to 640x480
    ret = set_gfx_mode(GFX_AUTODETECT_WINDOWED, 640, 480, 0, 0);
    if (ret != 0) {
        allegro_message(allegro_error);
        return;
    }

    //display screen resolution
    textprintf(screen, font, 0, 0, 15, 
        "DoLines Program - %dx%d - Press ESC to quit", 
        SCREEN_W, SCREEN_H);

    //wait for keypress
    while(!key[KEY_ESC])
    {
        //set a random location
        x1 = 10 + rand() % (SCREEN_W-20);
        y1 = 10 + rand() % (SCREEN_H-20);
        x2 = 10 + rand() % (SCREEN_W-20);
        y2 = 10 + rand() % (SCREEN_H-20);

        //set a random color
        red = rand() % 255;
        green = rand() % 255;
        blue = rand() % 255;
        color = makecol(red,green,blue);
        
        //draw the line using the callback function
        stop = 0;
        do_line(screen,x1,y1,x2,y2,color,*doline);
        
        rest(200);
    }

    //end program
    allegro_exit();
}

END_OF_MAIN();

