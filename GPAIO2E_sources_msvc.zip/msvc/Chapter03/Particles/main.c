/////////////////////////////////////////////////////////////////////////
// Game Programming All In One, Second Edition
// Source Code Copyright (C)2004 by Jonathan S. Harbour
// Chapter 3 - Particles Program
/////////////////////////////////////////////////////////////////////////

#include "math.h"
#include "allegro.h"

#define NUM 6

//particle structure
struct particle
{
    double mass;
    double x, y;
    long oldX, oldY;
    long xp;
    long yp;
    double ax;
    double ay;
    double vx;
    double vy;

}p[NUM];

int CX, CY;

void resetparticle(int n);
void updateparticles();
void resetall();


void attract(struct particle *A, struct particle *B)
{
    double distance;
    double dist, distX, distY;
    double transX, transY;

    //increase position by velocity value
    A->x += A->vx;
    A->y += A->vy;
    
    //calculate distance between particles
    distX = A->x - B->x;
    distY = A->y - B->y;
    dist = distX * distX + distY * distY;
    if (dist != 0)
        distance = 1 / dist;
    else
        distance = 0;

    transX = distX * distance;
    transY = distY * distance;
    
    //acceleration = mass * distance
    A->ax = -1 * B->mass * transX;
    A->ay = -1 * B->mass * transY;
    
    //increase velocity by acceleration value
    A->vx += A->ax;
    A->vy += A->ay;

    //scale position to the screen
    A->xp = CX + A->x;// - p[0].x;
    A->yp = CY - A->y;// + p[0].y;

}

void update()
{
    int n;
    int i;

    //erase old particle
    for (n = 0; n < NUM; n++)

    //calculate gravity for each particle
    for (n = 0; n < NUM; n++)
    {
        circlefill(screen, p[n].oldX, p[n].oldY, 5, 0);

        //apply gravity between every particle
        for (i = 0; i < NUM; i++)
        {
            if (i != n)
                attract(&p[n], &p[i]);
        }

        //reset particle if it gets too far away
        if (p[n].xp < -1000 ||
            p[n].xp > 1000 ||
            p[n].yp < -1000 ||
            p[n].yp > 1000)
        {
            resetparticle(n);
        }

        //plot the new particle
        circlefill(screen, p[n].xp, p[n].yp, 4, 7);

        //keep track of the current position
        p[n].oldX = p[n].xp;
        p[n].oldY = p[n].yp;
    }

    //draw the primary particle
    circlefill(screen, p[0].xp, p[0].yp, 5, 15);

}


void resetparticle(int n)
{
    p[n].mass = 0.001;
    p[n].ax = 0;
    p[n].ay = 0;
    p[n].xp = 0;
    p[n].yp = 0;
    p[n].x = rand() % SCREEN_W/4;
    p[n].y = rand() % SCREEN_H/4;
    p[n].vx = 0;
    p[n].vy = 0;
}


void resetall()
{
    int n;
    CX = SCREEN_W / 2;
    CY = SCREEN_H / 2;

    for (n = 0; n < NUM; n++)
        resetparticle(n);
}

void main(void)
{
    int ret;
    
    //initialize some stuff
    allegro_init(); 
    install_keyboard(); 
    install_timer();
    srand(time(NULL));

    //initialize video mode to 640x480
    ret = set_gfx_mode(GFX_AUTODETECT_WINDOWED, 640, 480, 0, 0);
    if (ret != 0) {
        allegro_message(allegro_error);
        return;
    }

    //display screen resolution
    textprintf(screen, font, 0, 0, 15, 
        "Particles Program - %dx%d - Press ESC to quit", 
        SCREEN_W, SCREEN_H);

    resetall();

    //wait for keypress
    while(!key[KEY_ESC])
    {
        update();
        
    }

    //end program
    allegro_exit();
}

END_OF_MAIN();

