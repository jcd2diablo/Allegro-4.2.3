/////////////////////////////////////////////////////////////////////////
// Game Programming All In One, Second Edition
// Source Code Copyright (C)2004 by Jonathan S. Harbour
// Chapter 3 - Rect Program
/////////////////////////////////////////////////////////////////////////

#include "allegro.h"

void main(void)
{
    int x1,y1,x2,y2;
    int red,green,blue,color;
    int ret;
    
    //initialize Allegro
    allegro_init(); 
    
    //initialize the keyboard
    install_keyboard(); 

    //initialize video mode to 640x480
    ret = set_gfx_mode(GFX_AUTODETECT_WINDOWED, 640, 480, 0, 0);
    if (ret != 0) {
        allegro_message(allegro_error);
        return;
    }

    //display screen resolution
    textprintf(screen, font, 0, 0, 15, 
        "Rect Program - %dx%d - Press ESC to quit", 
        SCREEN_W, SCREEN_H);

    //wait for keypress
    while(!key[KEY_ESC])
    {
        //set a random location
        x1 = 10 + rand() % (SCREEN_W-20);
        y1 = 10 + rand() % (SCREEN_H-20);
        x2 = 10 + rand() % (SCREEN_W-20);
        y2 = 10 + rand() % (SCREEN_H-20);
        
        //set a random color
        red = rand() % 255;
        green = rand() % 255;
        blue = rand() % 255;
        color = makecol(red,green,blue);
        
        //draw the pixel
        rect(screen,x1,y1,x2,y2,color);
    }

    //end program
    allegro_exit();
}

END_OF_MAIN();

