/////////////////////////////////////////////////////////////////////////
// Game Programming All In One, Second Edition
// Source Code Copyright (C)2004 by Jonathan S. Harbour
// Chapter 3 - Splines Program
/////////////////////////////////////////////////////////////////////////

#include "allegro.h"

void main(void)
{
    int points[8] = {0,240,300,0,200,0,639,240};
    int ret;
    int y1, y2;
    int dir1, dir2;
    
    //initialize Allegro
    allegro_init(); 
    install_keyboard(); 
    install_timer();

    //initialize video mode to 640x480
    ret = set_gfx_mode(GFX_AUTODETECT_WINDOWED, 640, 480, 0, 0);
    if (ret != 0) {
        allegro_message(allegro_error);
        return;
    }

    //display screen resolution
    textprintf(screen, font, 0, 0, 15, 
        "Splines Program - %dx%d - Press ESC to quit", 
        SCREEN_W, SCREEN_H);

    y1 = 0;
    y2 = SCREEN_H;
    dir1 = 10;
    dir2 = -10;

    //wait for keypress
    while(!key[KEY_ESC])
    {
        //modify the first spline point
        y1 += dir1;
        if (y1 > SCREEN_H)
        {
            dir1 = -10;
        }
        if (y1 < 0)
            dir1 = 10;
        points[3] = y1;
        
        //modify the second spline point
        y2 += dir2;
        if (y2++ > SCREEN_H)
        {
            dir2 = -10;
        }
        if (y2 < 0)
            dir2 = 10;
        points[5] = y2;
       
        //draw the spline, pause, then erase it
        spline(screen, points, 15);
        rest(30); // replaced sleep()
        spline(screen, points, 0);
        
    }

    //end program
    allegro_exit();
}

END_OF_MAIN();

