#include <allegro.h>

int main() 
{ 
    //initialize Allegro
    allegro_init();      
    set_gfx_mode(GFX_AUTODETECT_WINDOWED, 640, 480, 0, 0);
    install_keyboard();
    text_mode(-1);

    //test the text output functions
    textout(screen, font, "This was displayed by textout", 0, 10, 15);

    textout_centre(screen, font, "Sample of textout_centre function", 
        SCREEN_W/2, 50, 14);

    textout_justify(screen, font, "Sample output by textout_justify",
        SCREEN_W/2 - 200, SCREEN_W/2 + 200, 100, 200, 13);

    textprintf(screen, font, 0, 150, 12, "Screen resolution = %i x %i",
        SCREEN_W, SCREEN_H);

    textprintf_centre(screen, font, SCREEN_W/2, 200, 10, 
        "%s, %s!", "Hello", "World");

    textprintf_justify(screen, font, SCREEN_W/2 - 200, 
        SCREEN_W/2 + 200, 250, 400, 7, "A L L E G R O !");


    //main loop
    while(! key[KEY_ESC]) { }

    allegro_exit();
    return 0;     
}     
END_OF_MAIN();


