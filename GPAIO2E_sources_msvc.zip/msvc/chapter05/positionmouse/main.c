

#include "allegro.h"

#define WHITE makecol(255,255,255)

int mouseinside(int x1,int y1,int x2,int y2)
{
    if (mouse_x > x1 && mouse_x < x2 && mouse_y > y1 && mouse_y < y2)
        return 1;
    else
        return 0;
}

void main(void)
{
    int n;
    BITMAP *ship;
    
    //initialize program    
    allegro_init();
    set_color_depth(16);
    set_gfx_mode(GFX_AUTODETECT_FULLSCREEN, 640, 480, 0, 0);
    install_keyboard();
    install_mouse();
    textout(screen,font,"PositionMouse Program (ESC to quit)",0,0,WHITE);
    
    //load the custom mouse pointer
    ship = load_bitmap("spaceship.bmp", NULL);
    set_mouse_sprite(ship);
    set_mouse_sprite_focus(ship->w/2,ship->h/2);
    show_mouse(screen);
 
    //draw the wormholes
    for (n=0;n<20;n++)
    {
        circle(screen,150-3*n,150-3*n,n*2,makecol(10*n,10*n,10*n));
        circle(screen,480+3*n,330+3*n,n*2,makecol(10*n,10*n,10*n));
    }
 
    while (!key[KEY_ESC])
    {
        if (mouseinside(90,90,150,150))
            position_mouse(550,400);
        
        if (mouseinside(480,330,540,390))
            position_mouse(80,80);
    }
    set_mouse_sprite(NULL);
    destroy_bitmap(ship);
    allegro_exit();
}
END_OF_MAIN();


