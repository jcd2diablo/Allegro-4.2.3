
#include <stdio.h>
#include "allegro.h"

#define WHITE makecol(255,255,255)
#define LTGREEN makecol(192,255,192)
#define LTRED makecol(255,192,192)
#define LTBLUE makecol(192,192,255)
int curline = 1;

void print(char *s, int color)
{
    //print text with automatic linefeed
    textout(screen, font, s, 10, (curline++) * 12, color);
}

void printjoyinfo()
{
    char *s="";
    int n, ax;
    
    //display joystick information
    sprintf(s, "Number of Joysticks: %d", num_joysticks);
    print(s, WHITE);
    print("",0);
    
    //display stick information
    sprintf(s, "Number of Sticks: %d", joy[0].num_sticks);
    print(s, LTGREEN);
    for (n=0; n<joy[0].num_sticks; n++)
    {
        sprintf(s, "Stick %d: %s", n, joy[0].stick[n].name);
        print(s, LTGREEN);
        sprintf(s, "  Number of Axes: %d", joy[0].stick[n].num_axis);
        print(s, LTBLUE);
        for (ax=0; ax<joy[0].stick[n].num_axis; ax++)
        {
            sprintf(s,"    Axis %d: %s", ax, 
                joy[0].stick[n].axis[ax].name);
            print(s, LTRED);
        }
    }
    
    //display button information
    print("",0);
    sprintf(s, "Number of Buttons: %d", joy[0].num_buttons);
    print(s, LTGREEN);
    for (n=0; n<joy[0].num_buttons; n++)
    {
        sprintf(s,"  Button %d: %s", n, joy[0].button[n].name);
        print(s, LTBLUE);
    }
}

void main(void)
{

    //initialize program    
    allegro_init();
    set_color_depth(16);
    set_gfx_mode(GFX_AUTODETECT_WINDOWED, 640, 480, 0, 0);
    install_keyboard();

    //install the joystick handler
    install_joystick(JOY_TYPE_AUTODETECT);
    poll_joystick();

    //display title
    print("ScanJoystick Program", WHITE);
    print("---------------------------------------", WHITE);

    //look for a joystick
    if (num_joysticks > 0)
        printjoyinfo();
    else
        print("No joystick could be found", WHITE);
    
    //pause and exit
    print("",0);
    print("Press any key...", WHITE);
    while (!keypressed()) { }
    allegro_exit();
}

END_OF_MAIN();

