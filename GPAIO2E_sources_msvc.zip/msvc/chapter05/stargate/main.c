
#include "allegro.h"

#define WHITE makecol(255,255,255)
#define BLUE makecol(64,64,255)
#define RED makecol(255,64,64)

typedef struct POINT
{
    int x, y;
} POINT;

POINT coords[] = {{25,235},
                  {15,130},
                  {60,50},
                  {165,10},
                  {270,50},
                  {325,135},
                  {315,235}};

BITMAP *stargate;
BITMAP *water;
BITMAP *symbols[7];
int count = 0;

//helper function to highlight each shevron
void shevron(int num)
{
    floodfill(screen, 20+coords[num].x, 50+coords[num].y, RED);

    if (++count > 6)
    { 
        masked_blit(water,screen,0,0,67,98,water->w,water->h);
        textout_centre(screen,font,"WORMHOLE ESTABLISHED!",
            SCREEN_W/2, SCREEN_H-30, RED);
    }
}

//main function
void main(void)
{
    int n;

    //initialize program    
    allegro_init();
    set_color_depth(16);
    set_gfx_mode(GFX_AUTODETECT_FULLSCREEN, 640, 480, 0, 0);
    install_keyboard();

    //load the stargate image
    stargate = load_bitmap("stargate.bmp", NULL);
    blit(stargate,screen,0,0,20,50,stargate->w,stargate->h);
    
    //load the water image
    water = load_bitmap("water.bmp", NULL);

    //load the symbol images
    symbols[0] = load_bitmap("symbol1.bmp", NULL);
    symbols[1] = load_bitmap("symbol2.bmp", NULL);
    symbols[2] = load_bitmap("symbol3.bmp", NULL);
    symbols[3] = load_bitmap("symbol4.bmp", NULL);
    symbols[4] = load_bitmap("symbol5.bmp", NULL);
    symbols[5] = load_bitmap("symbol6.bmp", NULL);
    symbols[6] = load_bitmap("symbol7.bmp", NULL);
    
    //display the symbols
    textout(screen,font,"DIALING SEQUENCE", 480, 50, WHITE);
    for (n=0; n<7; n++)
    {
        textprintf(screen,font,480,70+n*40,BLUE,"%d", n+1);
        blit(symbols[n],screen,0,0,530,70+n*40,32,32);
    }
    
    //display title
    textout(screen,font,"STARGATE PROGRAM (ESC to quit)", 0, 0, RED);
    textout(screen,font,"PRESS THE CORRECT KEYS (A-Z) "\
        "TO DIAL THE STARGATE", 0, 10, RED);
 
    //main loop
    while (!key[KEY_ESC])
    {
        //check for proper sequence
        switch (count)
        {
            case 0:
                if (key[KEY_A]) shevron(0);
                break;
            case 1:
                if (key[KEY_Y]) shevron(1);
                break;
            case 2:
                if (key[KEY_B]) shevron(2);
                break;
            case 3:
                if (key[KEY_A]) shevron(3);
                break;
            case 4:
                if (key[KEY_B]) shevron(4);
                break;
            case 5:
                if (key[KEY_T]) shevron(5);
                break;
            case 6:
                if (key[KEY_U]) shevron(6);
                break;
        }
    }
    
    //clean up
    destroy_bitmap(stargate);
    destroy_bitmap(water);
    for (n=0; n<7; n++)
        destroy_bitmap(symbols[n]);
        
    allegro_exit();
}
END_OF_MAIN();

