
#include "allegro.h"

#define WHITE makecol(255,255,255)
#define BLACK makecol(0,0,0)
#define AQUA makecol(0,200,255)

void main(void)
{
    int n, color, value;
    BITMAP *lever;

    //initialize program    
    allegro_init();
    set_color_depth(16);
    set_gfx_mode(GFX_AUTODETECT_WINDOWED, 640, 480, 0, 0);
    install_keyboard();
    install_mouse();
    textout(screen,font,"MouseWheel Program (ESC to quit)",0,0,WHITE);
    textout(screen,font,"USE MOUSE WHEEL TO MOVE THE LEVER",0,10,WHITE);
    
    //load the control lever image
    lever = load_bitmap("lever.bmp", NULL);
    
    //draw the throttle control
    for (n=0; n<200; n++)
    {
        color = makecol(255-n,10,10);
        rectfill(screen, 200, 40 + n * 2, 400, 42 + n * 2, color);
    }
    
    value=200;
    position_mouse_z(value);
 
    while (!key[KEY_ESC])
    {
        //erase the lever
        rectfill(screen, 450, 29 + value, 550, value + 65, BLACK);

        //update lever position
        value = mouse_z;
        if (value < 0) 
            value = 0;
        if (value > 390)
            value = 390;

        //draw the lever
        blit(lever, screen, 0, 0, 450, 30 + value, lever->w, lever->h);
        
        //display value
        textprintf(screen, font, 520, 30 + value + lever->h / 2,
            AQUA,"%d", value);
        
        rest(30);
    }

    allegro_exit();
}
END_OF_MAIN();


