
#include "allegro.h"

#define WHITE makecol(255,255,255)
#define BLACK makecol(0,0,0)

BITMAP *back;
BITMAP *paddle;
BITMAP *ball;

int score = 0, paddlex, paddley = 430;
int ballx = 100, bally = 100;
int dirx = 1, diry = 2;

void updateball()
{
    //update ball x
    ballx += dirx;
    
    //hit left?
    if (ballx < 0)
    {
        ballx = 1;
        dirx = rand() % 2 + 4;
    }
    
    //hit right?
    if (ballx > SCREEN_W - ball->w - 1)
    {
        ballx = SCREEN_W - ball->w - 1;
        dirx = rand() % 2 - 6;
    }

    //update ball y
    bally += diry;
    
    //hit top?
    if (bally < 0)
    {
        bally = 1;
        diry = rand() % 2 + 4;
    }
    
    //hit bottom?
    if (bally > SCREEN_H - ball->h - 1)
    {
        score--;
        bally = SCREEN_H - ball->h - 1;
        diry = rand() % 2 - 6;
    }
    
    //hit the paddle?
    if (ballx > paddlex && ballx < paddlex+paddle->w &&
        bally > paddley && bally < paddley+paddle->h)
    {
        score++;
        bally = paddley - ball->h - 1;
        diry = rand() % 2 - 6;
    }

    //draw ball
    masked_blit(ball, screen, 0, 0, ballx, bally, ball->w, ball->h);
}

void main(void)
{
    int d1, d2, pos, startpos;

    //initialize program    
    allegro_init();
    set_color_depth(16);
    set_gfx_mode(GFX_AUTODETECT_FULLSCREEN , 640, 480, 0, 0);
    srand(time(NULL));
    install_keyboard();

    //install the joystick handler
    install_joystick(JOY_TYPE_AUTODETECT);
    poll_joystick();

    //look for a joystick
    if (num_joysticks == 0)
    {
        textout(screen,font,"No joystick could be found",0,20,WHITE);
        while(!keypressed());
        return;
    }
    
    //store starting stick position
    startpos = joy[0].stick[0].axis[0].pos;

    //load the background image
    back = load_bitmap("background.bmp", NULL);
    
    //load the paddle image and position it
    paddle = load_bitmap("paddle.bmp", NULL);
    paddlex = SCREEN_W/2 - paddle->w/2;
    
    //load the ball image
    ball = load_bitmap("ball.bmp", NULL);
    
    //set text output to transparent
    text_mode(-1);
    
    //main loop
    while (!key[KEY_ESC])
    {
        //clear screen the slow way (redraw background)
        blit(back, screen, 0, 0, 0, 0, back->w, back->h);

        //update ball position
        updateball();

        //read the joystick
        poll_joystick();
        d1 = joy[0].stick[0].axis[0].d1;
        d2 = joy[0].stick[0].axis[0].d2;
        pos = joy[0].stick[0].axis[0].pos;
        
        //see if stick moved left
        if (d1 || pos < startpos+10) paddlex -= 10;
        if (paddlex < 2) paddlex = 2;
        
        //see if stick moved right
        if (d2 || pos > startpos-10) paddlex += 10;
        if (paddlex > SCREEN_W - paddle->w - 2) 
            paddlex = SCREEN_W - paddle->w - 2;
        
        //display text messages
        textout(screen, font, "TestJoystick Program (ESC to quit)",
            2, 2, BLACK);
        textprintf(screen, font, 2, 20, BLACK,
            "Stick d1,d2,pos: %d,%d,%d", d1, d2, pos);
        textprintf_right(screen, font, SCREEN_W - 2, 2, BLACK,
            "SCORE: %d", score);
        
        //draw the paddle
        blit(paddle,screen,0,0,paddlex,paddley,paddle->w,paddle->h);
        
        rest(20);
    }
    
    destroy_bitmap(back);
    destroy_bitmap(paddle);
    destroy_bitmap(ball);
    return;
}

END_OF_MAIN();

