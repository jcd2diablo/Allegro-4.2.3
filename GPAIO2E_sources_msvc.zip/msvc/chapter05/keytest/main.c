
#include <stdio.h>
#include "allegro.h"

#define WHITE makecol(255,255,255)

void main(void)
{
    int k, x, y;
    int scancode, ascii;

    //initialize program    
    allegro_init();
    set_color_depth(16);
    set_gfx_mode(GFX_AUTODETECT_WINDOWED, 640, 480, 0, 0);
    install_keyboard();
    
    //display title
    textout(screen,font,"KeyTest Program", 0, 0, WHITE);
    textout(screen,font,"Press a key (ESC to quit)...", 0, 20, WHITE);
 
    //set starting position for text
    x = SCREEN_W/2 - 60;
    y = SCREEN_H/2 - 20;
    
    while (!key[KEY_ESC])
    {
        //get and convert scan code
        k = readkey();
        scancode = (k >> 8);
        ascii = scancode_to_ascii(scancode);
        
        //display key values
        textprintf(screen, font, x, y, WHITE,
            "Key value  = %-6d", k); 
        textprintf(screen, font, x, y+15, WHITE, 
            "Scan code  = %-6d", scancode);
        textprintf(screen, font, x, y+30, WHITE,
            "ASCII code = %-6d", ascii);
        textprintf(screen, font, x, y+45, WHITE,
            "Character  = %-6c", (char)ascii);
    }
    allegro_exit();
}
END_OF_MAIN();

