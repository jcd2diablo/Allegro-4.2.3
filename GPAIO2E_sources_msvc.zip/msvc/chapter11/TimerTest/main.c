
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include "allegro.h"

#define MODE GFX_AUTODETECT_FULLSCREEN
#define WIDTH 640
#define HEIGHT 480
#define MAX 6
#define BLACK makecol(0,0,0)
#define WHITE makecol(255,255,255)

//define the sprite structure
typedef struct SPRITE
{
    int dir, alive;
    int x,y;
    int width,height;
    int xspeed,yspeed;
    int xdelay,ydelay;
    int xcount,ycount;
    int curframe,maxframe,animdir;
    int framecount,framedelay;
}SPRITE;

//variables
BITMAP *back;
BITMAP *temp;
BITMAP *sprite_images[10][10];
SPRITE *sprites[10];
BITMAP *buffer;
int n, f;

//timer variables
int start;
int counter;
int ticks;
int framerate;

void updatesprite(SPRITE *spr)
{
    //update x position
    if (++spr->xcount > spr->xdelay)
    {
        spr->xcount = 0;
        spr->x += spr->xspeed;
    }

    //update y position
    if (++spr->ycount > spr->ydelay)
    {
        spr->ycount = 0;
        spr->y += spr->yspeed;
    }

    //update frame based on animdir
    if (++spr->framecount > spr->framedelay)
    {
        spr->framecount = 0;
        if (spr->animdir == -1)
        {
            if (--spr->curframe < 0)
                spr->curframe = spr->maxframe;
        }
        else if (spr->animdir == 1)
        {
            if (++spr->curframe > spr->maxframe)
                spr->curframe = 0;
        }
    }
}

void warpsprite(SPRITE *spr)
{
    //simple screen warping behavior
    //Allegro takes care of clipping
    if (spr->x < 0 - spr->width)
    {
        spr->x = SCREEN_W;
    }

    else if (spr->x > SCREEN_W)
    {
        spr->x = 0 - spr->width;
    }

    if (spr->y < 0)
    {
        spr->y = SCREEN_H - spr->height-1;
    }

    else if (spr->y > SCREEN_H - spr->height)
    {
        spr->y = 0;
    }

}

//reuse our friendly tile grabber from chapter 9
BITMAP *grabframe(BITMAP *source, 
                  int width, int height, 
                  int startx, int starty, 
                  int columns, int frame)
{
    BITMAP *temp = create_bitmap(width,height);

    int x = startx + (frame % columns) * width;
    int y = starty + (frame / columns) * height;

    blit(source,temp,x,y,0,0,width,height);

    return temp;
}

void loadsprites(void)
{
    //load dragon sprite
    temp = load_bitmap("dragon.bmp", NULL);
    for (n=0; n<6; n++)
        sprite_images[0][n] = grabframe(temp,128,64,0,0,3,n);
    destroy_bitmap(temp);

    //initialize the dragon (sprite 0)
    sprites[0] = malloc(sizeof(SPRITE));
    sprites[0]->x = 500;
    sprites[0]->y = 0;
    sprites[0]->width = sprite_images[0][0]->w;
    sprites[0]->height = sprite_images[0][0]->h;
    sprites[0]->xdelay = 1;
    sprites[0]->ydelay = 0;
    sprites[0]->xcount = 0;
    sprites[0]->ycount = 0;
    sprites[0]->xspeed = -5;
    sprites[0]->yspeed = 0;
    sprites[0]->curframe = 0;
    sprites[0]->maxframe = 5;
    sprites[0]->framecount = 0;
    sprites[0]->framedelay = 5;
    sprites[0]->animdir = 1;

    //load fish sprite
    temp = load_bitmap("fish.bmp", NULL);
    for (n=0; n<3; n++)
        sprite_images[1][n] = grabframe(temp,64,32,0,0,3,n);
    destroy_bitmap(temp);

    //initialize the fish (sprite 1)
    sprites[1] = malloc(sizeof(SPRITE));
    sprites[1]->x = 300;
    sprites[1]->y = 400;
    sprites[1]->width = sprite_images[1][0]->w;
    sprites[1]->height = sprite_images[1][0]->h;
    sprites[1]->xdelay = 1;
    sprites[1]->ydelay = 0;
    sprites[1]->xcount = 0;
    sprites[1]->ycount = 0;
    sprites[1]->xspeed = 3;
    sprites[1]->yspeed = 0;
    sprites[1]->curframe = 0;
    sprites[1]->maxframe = 2;
    sprites[1]->framecount = 0;
    sprites[1]->framedelay = 8;
    sprites[1]->animdir = 1;

    //load crab sprite
    temp = load_bitmap("crab.bmp", NULL);
    for (n=0; n<4; n++)
        sprite_images[2][n] = grabframe(temp,64,32,0,0,4,n);
    destroy_bitmap(temp);

    //initialize the crab (sprite 2)
    sprites[2] = malloc(sizeof(SPRITE));
    sprites[2]->x = 300;
    sprites[2]->y = 212;
    sprites[2]->width = sprite_images[2][0]->w;
    sprites[2]->height = sprite_images[2][0]->h;
    sprites[2]->xdelay = 6;
    sprites[2]->ydelay = 0;
    sprites[2]->xcount = 0;
    sprites[2]->ycount = 0;
    sprites[2]->xspeed = 2;
    sprites[2]->yspeed = 0;
    sprites[2]->curframe = 0;
    sprites[2]->maxframe = 3;
    sprites[2]->framecount = 0;
    sprites[2]->framedelay = 20;
    sprites[2]->animdir = 1;

    //load bee sprite
    temp = load_bitmap("bee.bmp", NULL);
    for (n=0; n<6; n++)
        sprite_images[3][n] = grabframe(temp,50,40,0,0,6,n);
    destroy_bitmap(temp);

    //initialize the crab (sprite 2)
    sprites[3] = malloc(sizeof(SPRITE));
    sprites[3]->x = 100;
    sprites[3]->y = 120;
    sprites[3]->width = sprite_images[3][0]->w;
    sprites[3]->height = sprite_images[3][0]->h;
    sprites[3]->xdelay = 1;
    sprites[3]->ydelay = 0;
    sprites[3]->xcount = 0;
    sprites[3]->ycount = 0;
    sprites[3]->xspeed = -3;
    sprites[3]->yspeed = 0;
    sprites[3]->curframe = 0;
    sprites[3]->maxframe = 5;
    sprites[3]->framecount = 0;
    sprites[3]->framedelay = 8;
    sprites[3]->animdir = 1;

  //load skeeter sprite
    temp = load_bitmap("skeeter.bmp", NULL);
    for (n=0; n<6; n++)
        sprite_images[4][n] = grabframe(temp,50,40,0,0,6,n);
    destroy_bitmap(temp);

    //initialize the crab (sprite 2)
    sprites[4] = malloc(sizeof(SPRITE));
    sprites[4]->x = 500;
    sprites[4]->y = 70;
    sprites[4]->width = sprite_images[4][0]->w;
    sprites[4]->height = sprite_images[4][0]->h;
    sprites[4]->xdelay = 1;
    sprites[4]->ydelay = 0;
    sprites[4]->xcount = 0;
    sprites[4]->ycount = 0;
    sprites[4]->xspeed = 4;
    sprites[4]->yspeed = 0;
    sprites[4]->curframe = 0;
    sprites[4]->maxframe = 4;
    sprites[4]->framecount = 0;
    sprites[4]->framedelay = 2;
    sprites[4]->animdir = 1;

  //load snake sprite
    temp = load_bitmap("snake.bmp", NULL);
    for (n=0; n<8; n++)
        sprite_images[5][n] = grabframe(temp,100,50,0,0,4,n);
    destroy_bitmap(temp);

    //initialize the crab (sprite 2)
    sprites[5] = malloc(sizeof(SPRITE));
    sprites[5]->x = 350;
    sprites[5]->y = 200;
    sprites[5]->width = sprite_images[5][0]->w;
    sprites[5]->height = sprite_images[5][0]->h;
    sprites[5]->xdelay = 1;
    sprites[5]->ydelay = 0;
    sprites[5]->xcount = 0;
    sprites[5]->ycount = 0;
    sprites[5]->xspeed = -2;
    sprites[5]->yspeed = 0;
    sprites[5]->curframe = 0;
    sprites[5]->maxframe = 4;
    sprites[5]->framecount = 0;
    sprites[5]->framedelay = 6;
    sprites[5]->animdir = 1;
}

void main(void)
{

    //initialize
    allegro_init();
    set_color_depth(16);
    set_gfx_mode(MODE, WIDTH, HEIGHT, 0, 0);
    srand(time(NULL));
    text_mode(-1);
    install_keyboard();
    install_timer();

    //create double buffer
    buffer = create_bitmap(SCREEN_W,SCREEN_H);

    //load and draw the blocks
    back = load_bitmap("background.bmp", NULL);
    blit(back,buffer,0,0,0,0,back->w,back->h);

    //load and set up sprites
    loadsprites();

    //game loop
    while (!key[KEY_ESC])
    {
        //restore the background
        for (n=0; n<MAX; n++)
            blit(back, buffer, sprites[n]->x, sprites[n]->y, 
                sprites[n]->x, sprites[n]->y,
                sprites[n]->width, sprites[n]->height);

        //update the sprites
        for (n=0; n<MAX; n++)
        {
            updatesprite(sprites[n]);
            warpsprite(sprites[n]);
            draw_sprite(buffer, sprite_images[n][sprites[n]->curframe], 
                sprites[n]->x, sprites[n]->y);
        }

        //update ticks
        ticks++;

        //calculate framerate once per second
        if (clock() > start + 1000)
        {
            counter++;
            start = clock();
            framerate = ticks;
            ticks = 0;
        }
        
        //display framerate
        blit(back, buffer, 320-70, 330, 320-70, 330, 140, 20);
        textprintf_centre(buffer,font,320,330,WHITE,"COUNTER %d", counter);
        textprintf_centre(buffer,font,320,340,WHITE,"FRAMERATE %d", framerate);

        //update the screen
        acquire_screen();
        blit(buffer,screen,0,0,0,0,SCREEN_W-1,SCREEN_H-1);
        release_screen();
    }

    //remove objects from memory
    destroy_bitmap(back);
    destroy_bitmap(buffer);

    for (n=0; n<MAX; n++)
    {
        for (f=0; f<sprites[n]->maxframe+1; f++)
            destroy_bitmap(sprite_images[n][f]);

        free(sprites[n]);
    }

    return;
}

END_OF_MAIN();

