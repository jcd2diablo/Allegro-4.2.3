#ifndef DIRTY_H_INCLUDED
#define DIRTY_H_INCLUDED

#include "demo.h"

void dirty_rectangle(int x, int y, int w, int h);
void clear_dirty(BITMAP *bmp);
void draw_dirty(BITMAP *bmp);

#endif
